package com.example.dhdms.for_study;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Random;

public class Study_Main extends AppCompatActivity implements View.OnClickListener {

    EditText input,output;
    Button confirm;
    int randNum , count =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study__main);
        input = findViewById(R.id.Txt_InputNum);


        output = findViewById(R.id.Txt_ShowRes);
        confirm =findViewById(R.id.Btn_Confirm);
        confirm.setOnClickListener(this);
        Random R = new Random();
        this.randNum = R.nextInt(500)+500;
    }

    @Override
    public void onClick(View view)
    {
        count++;
        if(Integer.parseInt(input.getText().toString()) == this.randNum)
        {
            output.setText(count + "번째 성공했습니다.");
        }
        else
        {
            if(Integer.parseInt(input.getText().toString()) < this.randNum)
            {
                output.setText(input.getText().toString() + "보다 큽니다.");
            }
            else
            {
                output.setText(input.getText().toString() + "보다 작습니다755.");
            }
        }
    }
}
