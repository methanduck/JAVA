package com.example.dhdms.for_nstudy;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    EditText Txt_Http;
    WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button Btn_Cancel = findViewById(R.id.Btn_cancel);
        Button Btn_Confirm = findViewById(R.id.Btn_confirm);
        Button btn = findViewById(R.id.Button);
        Txt_Http = findViewById(R.id.Txt_http);
        webView = findViewById(R.id.web_View);
        Btn_Cancel.setOnClickListener(this);
        Btn_Confirm.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.Btn_cancel:
                Txt_Http.setText("http://");
                break;

            case R.id.Btn_confirm:
                Open_Browser();

            case R.id.Button:

        }
    }
    private void Open_Browser()
    {
        webView.loadUrl(Txt_Http.getText().toString());
        webView.requestFocus();
    }
}

